<?php $__env->startSection('content'); ?>
<!-- Preloader -->
<div class="preloader">
    <div class="cssload-speeding-wheel"></div>
</div>
<div id="wrapper">
        <!-- Left navbar-header -->
    <style>
    .slimScrollDiv{
        overflow: initial !important;
    }
    .label_color {
        color: #000000;
        padding-right: 26px;
    }
    .input-field{
        margin-left: 3%;
        margin-top: 5%;
    }
    .moves{
        margin-right: 20px;
    }
    .vtabs>ul>li>hr
    {
        margin-top: -10px !important;
        margin-bottom: 0;
    }

</style>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Page Content -->
<div id="page-wrapper" class="row">
    <div class="container-fluid">
            <div class="col-md-12 data-section">
                <button class="btn btn-default btn-xs btn-outline btn-circle m-t-5 filter-section-show hidden-sm hidden-md" style="display:none"><i class="fa fa-chevron-right"></i></button>
                <div class="row">
                    <div class="col-md-12">
                        <span id="timer-section">
                            <div class="nav navbar-top-links navbar-right pull-right m-t-10 m-b-0">
                                <a class="btn btn-outline btn-inverse timer-modal" href="javascript:;">Start Timer <i class="fa fa-check-circle text-success"></i></a>
                            </div>
                        </span>
                    </div>
                </div>

        <div class="row bg-title">
        <!-- .page title -->
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 bg-title-left">
            <h4 class="page-title"><i class="user-follow"></i> Buddy Feedback</h4>
        </div>
        <!-- /.page title -->
        <!-- .breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12 text-right bg-title-right">
            <a href="javascript:;" onclick="calendarData()" class="btn btn-outline btn-info btn-sm ">View on Calendar <i class="fa fa-calendar" aria-hidden="true"></i></a>



            <ol class="breadcrumb">
                <li><a href="../member/dashboard">Home</a></li>
                <li class="active">Buddy Feedback</li>
            </ol>
        </div>
        <!-- /.breadcrumb -->
    </div>

    <div class="row">

        <div class="col-md-12 panel-inverse">
            <div class="white-box">
                <div class="row" id="holidaySectionData">

                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <div class="vtabs flex-column list-group" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <ul class="nav tabs-vertical" style="border: 1px solid rgba(0,0,0,.125);">

                                    <li class="tab active listed" id="day_zero_id">
                                        <a data-toggle="tab" href="#" id="day_zero_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="true">
                                            <i class="fa fa-calendar"></i> Day Zero</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_one_id">
                                        <a data-toggle="tab" href="#" id="day_one_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day One</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_two_id">
                                        <a data-toggle="tab" href="#" id="day_two_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day Two</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_three_id">
                                        <a data-toggle="tab" href="#" id="day_three_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day Three</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_five_id">
                                        <a data-toggle="tab" href="#" id="day_five_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day Five</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_eight_id">
                                        <a data-toggle="tab" href="#" id="day_eight_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day Eight</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_eleven_id">
                                        <a data-toggle="tab" href="#" id="day_eleven_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day Eleven</a><hr>
                                    </li>
                                    <li class="tab nav-item listed" id="day_fourteen_id">
                                        <a data-toggle="tab" href="#" id="day_fourteen_id" data-toggle="tab" class="nav-link " aria-expanded="" aria-controls="v-pills-home" aria-selected="false">
                                            <i class="fa fa-calendar"></i> Day fourteen</a><hr style="margin-top: -11px !important;">
                                    </li>

                            </ul>
                            <!-- Day all tab -->
                            <div class="tab-content p-0" style="border: 1px solid rgba(0,0,0,.125);">
                                <div id="day_zero_tab_id" class="tab-pane active">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Zero
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Familiarization Call</h3>
                                                <div class="input-field">

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="submit" id="next_day_zero_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_one_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day One
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Introduction with the HOD's & Supervisor</h3>
                                                <div class="input-field">

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_one_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_one_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_two_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Two
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Discuss Agenda for the day</h3>
                                                <div class="input-field">
                                                    <p>1. Knowledge on</p>
                                                    <p>2. Mailing-Outlook</p>
                                                    <p>3. Teams</p>
                                                    <p>4. GreytHR & Others</p>
                                                    <p>5. HEPL Committees - Sports, Happiness Coordinators & POSH</p>
                                                    <p>6. Grievances (If any)</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_two_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_two_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_three_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Three
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Discussion on Road Map in HEPL</h3>
                                                <div class="input-field">
                                                    <p>1. About the Process</p>
                                                    <p>2. About Performance Recognition</p>
                                                    <p>3. Benefits & Perks</p>
                                                    <p>4. Company Polices</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_three_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_three_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_five_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Five
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Discussion with NEJO</h3>
                                                <div class="input-field">
                                                    <p>1. KT status</p>
                                                    <p>2. Training status</p>
                                                    <p>3. Training on HR Portal - GreytHR</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_five_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_five_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_eight_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Eight
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Discussion on 2nd week Process</h3>
                                                <div class="input-field">
                                                    <p>1. Status on last week process</p>
                                                    <p>2. Learning status on your process</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_eight_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_eight_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_eleven_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Eleven
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Discussion on Learning Workflow</h3>
                                                <div class="input-field">
                                                    <p>1. Status on workflow</p>
                                                    <p>2. BH & HODs Introduction</p>
                                                    <p>3. Refreshing Session on Policy, HR Tool Attendance cycle, Pay-cycle & Others</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_eleven_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_eleven_id" class="btn btn-info">Next </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="day_fourteen_tab_id" class="tab-pane">
                                    <div class="panel panel-info block4">
                                        <div class="panel-heading">
                                            <div class="caption">
                                                <i class="fa fa-calendar"></i> Day Fourteen
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-scrollable ">
                                                <h3 style="margin-left: 2%;">Suggest & Feedback</h3>
                                                <div class="input-field">
                                                    <p>1. Implementations (if any)</p>
                                                    <p>2. How the Buddy's assistance</p><br>

                                                    <input type="radio" id="poor" name="familiarization_call" value="poor">
                                                    <label for="poor" class="label_color"> Poor </label>

                                                    <input type="radio" id="average" name="familiarization_call" value="average">
                                                    <label for="average" class="label_color"> Average </label>

                                                    <input type="radio" id="verification" name="familiarization_call" value="good">
                                                    <label for="verification" class="label_color"> Good </label>

                                                    <input type="radio" id="verygood" name="familiarization_call" value="verygood">
                                                    <label for="verygood" class="label_color"> Very Good </label>

                                                    <input type="radio" id="excellent" name="familiarization_call" value="excellent">
                                                    <label for="excellent" class="label_color"> Excellent </label>

                                                </div>
                                                <div class="text-right moves">
                                                    <button type="button" id="previous_day_fourteen_id" class="btn btn-info">Previous </button>
                                                    <button type="submit" id="next_day_fourteen_id" class="btn btn-success">Submit </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                            </div>
                        </div>
                </div>

                </div>
            </div>
        </div>
    </div>

<!-- .right-sidebar -->
<div class="right-sidebar">
    <div id="right-sidebar-content">

    </div>
</div>
<!-- /.right-sidebar -->
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->


<div id="footer-sticky-notes" class="row hidden-xs hidden-sm">
    <div class="col-xs-12" id="sticky-note-header">
        <div class="col-xs-10" style="line-height: 30px">
        Sticky Notes <a href="javascript:;" onclick="showCreateNoteModal()" class="btn btn-success btn-outline btn-xs m-l-10"><i class="fa fa-plus"></i> Add Note</a>
            </div>
        <div class="col-xs-2">
            <a href="javascript:;" class="btn btn-default btn-circle pull-right" id="open-sticky-bar"><i class="fa fa-chevron-up"></i></a>
            <a style="display: none;" class="btn btn-default btn-circle pull-right" href="javascript:;" id="close-sticky-bar"><i class="fa fa-chevron-down"></i></a>
        </div>

    </div>

    <div id="sticky-note-list" style="display: none">


    </div>
</div>

<a href="javascript:;" id="sticky-note-toggle"><i class="icon-note"></i></a>

<div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            Loading ...
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<script src="../js/jquery.min.js"></script>
<!-- JS file -->
<script src="../pro_js/buddy/buddy.js"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HRMS\resources\views/candidate/buddy_feedback.blade.php ENDPATH**/ ?>