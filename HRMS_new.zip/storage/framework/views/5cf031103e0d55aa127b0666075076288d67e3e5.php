 <!-- Bootstrap Core CSS -->
 <link href="../bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
 <link rel='stylesheet prefetch'
       href='https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css'>
 <link rel='stylesheet prefetch'
       href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.2/css/bootstrap-select.min.css'>

 <!-- This is Sidebar menu CSS -->
 <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">

 <link href="../plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
 <link href="../plugins/bower_components/sweetalert/sweetalert.css" rel="stylesheet">
 <link rel="stylesheet" href="../plugins/bower_components/switchery/dist/switchery.min.css">
 <!-- This is a Animation CSS -->
 <link href="../css/animate.css" rel="stylesheet">

     <link rel="stylesheet" href="../plugins/bower_components/custom-select/custom-select.css">
 <style>
     .col-in {
         padding: 0 20px !important;

     }

     .fc-event{
         font-size: 10px !important;
     }
     .front-dashboard .white-box{
         margin-bottom: 8px;
      }

     @media (min-width: 769px) {
         #wrapper .panel-wrapper{
             height: 530px;
             overflow-y: auto;
         }
     }

 </style>

         <!-- This is a Custom CSS -->
 <link href="../css/style.css" rel="stylesheet">
 <!-- color CSS you can use different color css from css/colors folder -->
 <!-- We have chosen the skin-blue (default.css) for this starter
    page. However, you can choose any other skin from folder css / colors .
    -->
 <link href="../css/colors/default.css" id="theme" rel="stylesheet">
 <link href="../plugins/froiden-helper/helper.css" rel="stylesheet">
 <link rel="stylesheet" href="../css/magnific-popup.css">
 <link href="../css/custom-new.css" rel="stylesheet">

    <link href="../css/rounded.css" rel="stylesheet">



 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
 <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
 <!--[if lt IE 9]>
 <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->





 <style>
     .sidebar .notify  {
     margin: 0 !important;
     }
     .sidebar .notify .heartbit {
     top: -23px !important;
     right: -15px !important;
     }
     .sidebar .notify .point {
     top: -13px !important;
     }
     .filter-section-show{
         position: relative !important;
     }
 </style>


    <link href="../less/icons/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="../css/auth.css" rel="stylesheet">



    <script>
        window.Laravel = {"csrfToken":"GvUlPs9LxYdFMAn0NzRt6LAA1V0YT75wJLOqb5P9"};
    </script>


    <style>
        #background-section {
            background: url("../img/login-bg.jpg") center center/cover no-repeat !important;
        }


    </style>


<?php /**PATH C:\xampp\htdocs\laravel\HRMS_new\resources\views/layouts/commoncss.blade.php ENDPATH**/ ?>