<?php $__env->startSection('content'); ?>
<!-- Preloader -->
<div class="preloader">
    <div class="cssload-speeding-wheel"></div>
</div>
<div id="wrapper">
        <!-- Left navbar-header -->
<style>
    .slimScrollDiv{
        overflow: initial !important;
    }
    .modal
    {
        padding-right: 26% !important;
    }
    .table thead th
    {
        border-bottom: 1px solid #dee2e6 !important;
    }
    .word-warpped
    {
        word-break: break-word;
        max-width: 160px;
        min-width: 160px;
    }
</style>

<?php echo $__env->make('layouts.sidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <!-- Page Content -->
    <div id="page-wrapper" class="row">
        <div class="container-fluid">




            <div class="
                        col-md-12
                        data-section" id ="section-task">
                <button class="btn btn-default btn-xs btn-outline btn-circle m-t-5 filter-section-show hidden-sm hidden-md" style="display:none"><i class="fa fa-chevron-right"></i></button>

                    <div class="row bg-title">

        <!-- .page title -->
        <div class="col-lg-6 col-md-4 col-sm-4 col-xs-12 bg-title-left">
            <h4 class="page-title"><i class="icon-user"></i> HR Buddy</h4>
        </div>
        <!-- /.page title -->

    </div>

<!-- .row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="white-box">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover toggle-circle default footable-loaded footable" id="users-table">
                        <thead>
                        <tr>
                            <th>EmployeeId</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile Number</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                         <tr>
                            <td>Emp101</td>
                            <td>Danny Ward</td>
                            <td>Dannyward@example.com</td>
                            <td>8373898787</td>
                            <td>
                                <button onclick="showAdd()" aria-expanded="false" data-toggle="dropdown" class="btn btn-default dropdown-toggle waves-effect waves-light" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                            </td>
                        </tr>

                        <tr>
                            <td>Emp102</td>
                            <td>Linda Craver</td>
                            <td>Lindacraver@example.com</td>
                            <td>8747638735</td>
                            <td>
                                <button onclick="showAdd()" aria-expanded="false" data-toggle="dropdown" class="btn btn-default dropdown-toggle waves-effect waves-light" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                            </td>
                        </tr>

                        <tr>
                            <td>Emp103</td>
                            <td>Jenni Sims</td>
                            <td>Jennisims@example.com</td>
                            <td>9876535487</td>
                            <td>
                                <button onclick="showAdd()" aria-expanded="false" data-toggle="dropdown" class="btn btn-default dropdown-toggle waves-effect waves-light" type="button"><i class="fa fa-eye" aria-hidden="true"></i></button>
                            </td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- .row -->


                <!-- .right-sidebar -->
<div class="right-sidebar">
    <div id="right-sidebar-content">

    </div>
</div>
<!-- /.right-sidebar -->
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->


<div id="footer-sticky-notes" class="row hidden-xs hidden-sm">
    <div class="col-xs-12" id="sticky-note-header">
        <div class="col-xs-10" style="line-height: 30px">
        Sticky Notes <a href="javascript:;" onclick="showCreateNoteModal()" class="btn btn-success btn-outline btn-xs m-l-10"><i class="fa fa-plus"></i> Add Note</a>
            </div>
        <div class="col-xs-2">
            <a href="javascript:;" class="btn btn-default btn-circle pull-right" id="open-sticky-bar"><i class="fa fa-chevron-up"></i></a>
            <a style="display: none;" class="btn btn-default btn-circle pull-right" href="javascript:;" id="close-sticky-bar"><i class="fa fa-chevron-down"></i></a>
        </div>

    </div>

    <div id="sticky-note-list" style="display: none">


    </div>
</div>

<div class="modal fade bs-modal-md in" id="edit-column-form" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-md" id="modal-data-application">
                <div class="modal-content" style="width: fit-content;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                        <span class="caption-subject font-red-sunglo bold uppercase" id="modelHeading"></span>
                    </div>
                    <div class="modal-body">
                        <table class="table table-custom dtable-striped table-bordered" style="width: max-content;">
                            <thead>
                                <tr>
                                  <th scope="col" rowspan="2">No</th>
                                  <th scope="col" rowspan="2">Question / Query</th>
                                  <th scope="col" colspan="6" class="text-center">Response</th>
                                </tr>
                                <tr>
                                  <th scope="col">STRONGLY DISAGREE</th>
                                  <th scope="col">DISAGREE</th>
                                  <th scope="col">NEITEHR AGREE NOR DISAGREE</th>
                                  <th scope="col">AGREE</th>
                                  <th scope="col">STRONGLY AGREE</th>
                                  <th scope="col">Remarks</th>
                                </tr>
                              </thead>

                            <tbody>
                              <tr>
                                <th scope="row">1</th>
                                <td><p class="word-warpped">My Buddy interacted with me pleasantly during the welcome session which helped me be comfortable and  bond well</p> </td>
                                <td><p style="color:green" class="fa fa-check"></p></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>none</td>

                              </tr>
                              <tr>
                                <th scope="row">2</th>
                                <td><p class="word-warpped">My Buddy gave me valuable and timely information about the Company and Work culture which helped me settle in well  without any confusion/ambiguity</p></td>
                                <td></td>
                                <td><p style="color:green" class="fa fa-check"></p></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">3</th>
                                <td><p class="word-warpped">My Buddy is well informed about the Company's Whos Who, Businesses, Processes, Policies etc and was able to answer all queries to my satisfaction</p></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">4</th>
                                <td><p class="word-warpped">My Buddy made me feel at ease while facilitating interactions with Functional/Dept Heads, Team Leads, My Peers and Colleagues</p></td>
                                    <td></td>
                                    <td></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td></td>
                                    <td></td>
                                    <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">5</th>
                                <td><p class="word-warpped">My Buddy was able to attend to all my concerns and helped me well to overcome my initial hesitations/sckepticism if any</p></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">6</th>
                                <td><p class="word-warpped">My Buddy was able to attend to all my concerns and helped me well to overcome my initial hesitations/sckepticism if any</p></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td></td>
                                    <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">7</th>
                                <td><p class="word-warpped">What went very well, during  my interactions with my Buddy</p></td>
                                    <td></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>none</td>
                              </tr>
                              <tr>
                                <th scope="row">8</th>
                                <td><p class="word-warpped">What didnt go well, during my interactions  with my buddy</p></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><p style="color:green" class="fa fa-check"></p></td>
                                    <td></td>
                                    <td>none</td>
                              </tr>
                            </tbody>
                          </table>
                    </div>

                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>


<a href="javascript:;" id="sticky-note-toggle"><i class="icon-note"></i></a>

<?php $__env->stopSection(); ?>
<script src="../js/jquery.min.js"></script>
<script>
function showAdd() {
        $('#edit-column-form').modal('show');
    }
</script>















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HRMS_new\resources\views/buddy/index.blade.php ENDPATH**/ ?>