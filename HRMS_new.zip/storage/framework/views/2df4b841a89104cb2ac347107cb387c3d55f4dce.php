<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="row">
    <div class="col-xs-12 col-lg-5" id="form-section">
        <div id="auth-logo">
            <img src="../public/img/hemas-logo.png" style="max-height: 50px" alt="Logo"/>
        </div>

        <div id="auth-form">



    <form class="form-horizontal form-material" id="loginform" action="../login" method="POST">
        <input type="hidden" name="_token" value="GvUlPs9LxYdFMAn0NzRt6LAA1V0YT75wJLOqb5P9">



        <div class="form-group ">
            <div class="col-xs-12">
                <input class="form-control" id="email" type="email" name="email" value="" autofocus
                    required="" placeholder="Email">

            </div>
        </div>
        <div class="form-group">
            <div class="col-xs-12">
                <input class="form-control" id="password" type="password" name="password" required=""
                    placeholder="Password">
                            </div>
        </div>

                <input type='hidden' name='recaptcha_token' id='recaptcha_token'>

        <div class="form-group">
            <div class="col-xs-12">
                <div class="checkbox checkbox-primary pull-left p-t-0">
                    <input id="checkbox-signup" type="checkbox" name="remember" >
                    <label for="checkbox-signup" class="text-dark"> Remember Me </label>
                </div>
                <a href="../password/reset" class="text-dark pull-right"><i class="fa fa-lock m-r-5"></i>
                    Forgot Password?</a>
            </div>
        </div>
        <div class="form-group text-center m-t-20">
            <div class="col-xs-12">
                <button class="btn btn-info btn-lg btn-block btn-rounded text-uppercase waves-effect waves-light"
                    type="submit">Log In</button>
            </div>
        </div>
        <div class="form-group">
            <script>
                var facebook = "../redirect/facebook";
                var google = "../redirect/google";
                var twitter = "../redirect/twitter";
                var linkedin = "../redirect/linkedin";
            </script>

                                                                    </div>
                                    <div class="form-group m-b-0">
                    <div class="col-sm-12 text-center">
                        <p>Don't have an account? <a href="../signup"
                                class="text-primary m-l-5"><b>Sign Up</b></a>
                        </p>
                    </div>
                </div>

                            <div class="form-group m-b-0">
                    <div class="col-sm-12 text-center">
                        <p>Go to Website <a href=".."
                                class="text-primary m-l-5"><b>Home</b></a></p>
                    </div>
                </div>

            </form>

        </div>
    </div>

    <div class="col-lg-7 visible-lg" id="background-section">

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HRMS\resources\views/login.blade.php ENDPATH**/ ?>