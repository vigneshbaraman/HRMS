<?php $__env->startSection('content'); ?>
<!-- Preloader -->
<div class="preloader">
    <div class="cssload-speeding-wheel"></div>
</div>
<div id="wrapper">
        <!-- Left navbar-header -->
    <style>
    .slimScrollDiv{
        overflow: initial !important;
    }
    .label_color {
        color: #000000;
        padding-right: 26px;
    }
    .input-field{
        margin-left: 3%;
        margin-top: 5%;
    }
    .moves{
        margin-right: 20px;
    }
    .vtabs>ul>li>hr
    {
        margin-top: -10px !important;
        margin-bottom: 0;
    }

</style>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Page Content -->
<div id="page-wrapper" class="row">
    <div class="container-fluid">
            <div class="col-md-12 data-section">
                <button class="btn btn-default btn-xs btn-outline btn-circle m-t-5 filter-section-show hidden-sm hidden-md" style="display:none"><i class="fa fa-chevron-right"></i></button>
                

        <div class="row bg-title">
        <!-- .page title -->
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 bg-title-left">
            <h4 class="page-title"><i class="user-follow"></i> Buddy Feedback</h4>
        </div>
        <!-- /.page title -->
        <!-- .breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12 text-right bg-title-right">
            



            <ol class="breadcrumb">
                <li><a href="../member/dashboard">Home</a></li>
                <li class="active">Buddy Feedback</li>
            </ol>
        </div>
        <!-- /.breadcrumb -->
    </div>

    <div id="day_zero_tab_id" class="tab-pane active">
        <div class="panel panel-info block4">
            
            <div class="portlet-body">
                <div class="table-scrollable ">
                    <div class="modern" style="margin-left: 2%; margin-top: 26px;">
                        <div class="row">
                            <div class="col-md-3">
                                <p>Employee Number</p>
                                <p>Employee Name</p>
                                <p>Department</p>
                                <p>Designation</p>
                                <p>Date of Joining</p>
                                <p>Work Location</p>
                                <p>Buddy Assigned </p>
                            </div>
                            <div class="col-md-3">
                                <p>: 900315</p>
                                <p>: Ram</p>
                                <p>: IT</p>
                                <p>: PHP Developer</p>
                                <p>: 19-03-2022</p>
                                <p>: WFH</p>
                                <p>: SHANTHI</p>
                            </div>
                        </div>
                    </div>

                    <div class="modal-body">
                        <table class="table table-custom dtable-striped table-bordered" style="width: max-content;">
                            <thead>
                              <tr>
                                <th scope="col" rowspan="2">No</th>
                                <th scope="col" rowspan="2">Question / Query</th>
                                <th scope="col" colspan="5" class="text-center">Response</th>
                              </tr>
                              <tr>
                                <th scope="col">STRONGLY DISAGREE</th>
                                <th scope="col">DISAGREE</th>
                                <th scope="col">NEITEHR AGREE NOR DISAGREE</th>
                                <th scope="col">AGREE</th>
                                <th scope="col">STRONGLY AGREE</th>
                                <th scope="col">Remarks</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <th scope="row">1</th>
                                <td>My Buddy interacted with me pleasantly during the welcome session which helped me be comfortable and  bond well </td>
                                <td class="text-center"><input type="checkbox" class="buddy_one" name="buddy_one" id="buddy_one" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_one" name="buddy_one" id="buddy_one" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_one" name="buddy_one" id="response2" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_one" name="buddy_one" id="response3" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_one" name="buddy_one" id="buddy_one" value="strongly agree"></td>
                                <td><input class="form-control" type="text" name="remarks" id="remarks"></td>

                              </tr>
                              <tr>
                                <th scope="row">2</th>
                                <td>My Buddy gave me valuable and timely information about the Company and Work culture which helped me settle in well  without any confusion/ambiguity</td>
                                <td class="text-center"><input type="checkbox" class="buddy_two" name="buddy_two" id="buddy_two" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_two" name="buddy_two" id="buddy_two" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_two" name="buddy_two" id="buddy_two" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_two" name="buddy_two" id="buddy_two" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_two" name="buddy_two" id="buddy_two" value="strongly agree"></td>
                                <td><input class="form-control" type="text" name="remarks" id="remarks"></td>
                              </tr>
                              <tr>
                                <th scope="row">3</th>
                                <td>My Buddy is well informed about the Company's Whos Who, Businesses, Processes, Policies etc and was able to answer all queries to my satisfaction</td>
                                <td class="text-center"><input type="checkbox" class="buddy_three" name="buddy_three" id="buddy_three" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_three" name="buddy_three" id="buddy_three" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_three" name="buddy_three" id="buddy_three" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_three" name="buddy_three" id="buddy_three" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_three" name="buddy_three" id="buddy_three" value="strongly agree"></td>
                                    <td><input class="form-control" type="text" name="remarks" id="remarks"></td>
                              </tr>
                              <tr>
                                <th scope="row">4</th>
                                <td>My Buddy made me feel at ease while facilitating interactions with Functional/Dept Heads, Team Leads, My Peers and Colleagues</td>
                                <td class="text-center"><input type="checkbox" class="buddy_four" name="buddy_four" id="buddy_four" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_four" name="buddy_four" id="buddy_four" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_four" name="buddy_four" id="buddy_four" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_four" name="buddy_four" id="buddy_four" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_four" name="buddy_four" id="buddy_four" value="strongly agree"></td>
                                    <td><input class="form-control" type="text" name="remarks" id="remarks"></td>
                              </tr>
                              <tr>
                                <th scope="row">5</th>
                                <td>My Buddy was able to attend to all my concerns and helped me well to overcome my initial hesitations/sckepticism if any</td>
                                <td class="text-center"><input type="checkbox" class="buddy_five" name="buddy_five" id="buddy_five" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_five" name="buddy_five" id="buddy_five" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_five" name="buddy_five" id="buddy_five" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_five" name="buddy_five" id="buddy_five" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_five" name="buddy_five" id="buddy_five" value="strongly agree"></td>
                                <td><input class="form-control" type="text" name="remarks" id="remarks"></td>
                              </tr>
                              <tr>
                                <th scope="row">6</th>
                                <td>My Buddy was able to attend to all my concerns and helped me well to overcome my initial hesitations/sckepticism if any</td>
                                <td class="text-center"><input type="checkbox" class="buddy_six" name="buddy_six" id="buddy_six" value="strongly disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_six" name="buddy_six" id="buddy_six" value="disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_six" name="buddy_six" id="buddy_six" value="neither agree nor disagree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_six" name="buddy_six" id="buddy_six" value="agree"></td>
                                <td class="text-center"><input type="checkbox" class="buddy_six" name="buddy_six" id="buddy_six" value="strongly agree"></td>
                                <td><input class="form-control" type="text" name="remarks" id="remarks"></td>
                              </tr>
                              <tr>
                                <th scope="row">7</th>
                                <td>What went very well, during  my interactions with my Buddy</td>
                                    <td class="text-center">1</td>
                                    <td class="text-center">2</td>
                                    <td class="text-center">3</td>
                                    <td></td>
                                    <td></td>
                              </tr>
                              <tr>
                                <th scope="row">8</th>
                                <td>What didnt go well, during my interactions  with my buddy</td>
                                    <td class="text-center">1</td>
                                    <td class="text-center">2</td>
                                    <td class="text-center">3</td>
                                    <td></td>
                                    <td></td>
                              </tr>
                              <tr>
                                <th scope="row">9</th>
                                <td>My suggestions for the Buddy Program to provide better experience to Future New Joiners</td>
                                    <td class="text-center">1</td>
                                    <td class="text-center">2</td>
                                    <td class="text-center">3</td>
                                    <td></td>
                                    <td></td>
                              </tr>

                            </tbody>
                          </table>
                    </div>
                    <div class="text-center moves">
                        <button type="submit" id="next_day_zero_id" class="btn btn-info">Submit </button>
                    </div>
                </div>
            </div>
        </div>
    </div>




<!-- .right-sidebar -->
<div class="right-sidebar">
    <div id="right-sidebar-content">

    </div>
</div>
<!-- /.right-sidebar -->
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->


<div id="footer-sticky-notes" class="row hidden-xs hidden-sm">
    <div class="col-xs-12" id="sticky-note-header">
        <div class="col-xs-10" style="line-height: 30px">
        Sticky Notes <a href="javascript:;" onclick="showCreateNoteModal()" class="btn btn-success btn-outline btn-xs m-l-10"><i class="fa fa-plus"></i> Add Note</a>
            </div>
        <div class="col-xs-2">
            <a href="javascript:;" class="btn btn-default btn-circle pull-right" id="open-sticky-bar"><i class="fa fa-chevron-up"></i></a>
            <a style="display: none;" class="btn btn-default btn-circle pull-right" href="javascript:;" id="close-sticky-bar"><i class="fa fa-chevron-down"></i></a>
        </div>

    </div>

    <div id="sticky-note-list" style="display: none">


    </div>
</div>

<a href="javascript:;" id="sticky-note-toggle"><i class="icon-note"></i></a>

<div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            Loading ...
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<script src="../js/jquery.min.js"></script>
<!-- JS file -->
<script src="../pro_js/buddy/buddy.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $('.buddy_one').click(function() {
            $('.buddy_one').not(this).prop('checked', false);
        });
        $('.buddy_two').click(function() {
            $('.buddy_two').not(this).prop('checked', false);
        });
        $('.buddy_three').click(function() {
            $('.buddy_three').not(this).prop('checked', false);
        });
        $('.buddy_four').click(function() {
            $('.buddy_four').not(this).prop('checked', false);
        });
        $('.buddy_five').click(function() {
            $('.buddy_five').not(this).prop('checked', false);
        });
        $('.buddy_six').click(function() {
            $('.buddy_six').not(this).prop('checked', false);
        });
    });
</script>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HRMS_new\resources\views/candidate/buddy_feedback.blade.php ENDPATH**/ ?>