<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BuddyController extends Controller
{
    public function buddy()
    {
        return view('candidate.buddy_feedback');
    }

    public function buddy_info()
    {
        return view('buddy.index');
    }

    public function profile()
    {
    return view('buddy.profile');

    }

    public function buddy_dashboard()
    {
    return view('buddy.dashboard');

    }
}
