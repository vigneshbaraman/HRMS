<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function admin_dashboard()
    {
        return view('admin.dashboard');
    }
    public function permission()
    {
        return view('admin.permission');
    }
    public function buisness()
    {
        return view('admin.buisness');
    }
    public function grade()
    {
        return view('admin.grade');
    }
    public function location()
    {
        return view('admin.location');
    }
    public function blood()
    {
        return view('admin.blood');
    }
    public function roll()
    {
        return view('admin.roll');
    }
    public function department()
    {
        return view('admin.department');
    }
    public function state()
    {
        return view('admin.state');
    }
    public function personnel()
    {
        return view('admin.personnel');
    }
    public function user()
    {
        return view('admin.users');
    }
    public function roles()
    {
        return view('admin.add_roles');
    }
    
}
