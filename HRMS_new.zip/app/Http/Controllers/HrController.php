<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HrController extends Controller
{
    public function index()
     {
        return view('HRSS.dashboard');
     }

     public function preOnboarding()
     {
         return view('HRSS.preOnboarding');
     }

     public function Candidate()
     {
         return view('HRSS.candidate');
     }

    public function profile()
    {
    return view('HRSS.profile');

    }

    public function userdocuments()
    {
    return view('HRSS.userdocuments');

    }
    public function CandidateProfile()
    {
    return view('HRSS.candidate_profile_add');

    }
}
