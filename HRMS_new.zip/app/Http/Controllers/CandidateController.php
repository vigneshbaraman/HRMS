<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CandidateController extends Controller
{
    public function preOnboarding()
    {
         return view('candidate.preOnboarding');
    }
    public function insertPreOnboarding(Request $request)
    {
           echo json_encode($_POST);
    }

    public function profile()
    {
    return view('candidate.profile');

    }

    public function candidate_dashboard()
    {
        return view('candidate.dashboard');
    }
}



